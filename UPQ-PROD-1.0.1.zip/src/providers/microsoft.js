const { Client } = require('@microsoft/microsoft-graph-client');
const { ClientSecretCredential } = require('@azure/identity');

function extractNotes(body) {
  if (!body?.content) return undefined;
  if (body.contentType === 'html') {
    // Strip HTML tags and decode basic entities
    return body.content
      .replace(/<[^>]+>/g, '')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .trim() || undefined;
  }
  return body.content.trim() || undefined;
}

class MicrosoftTasksProvider {
  constructor(config) {
    this.name = 'Microsoft Tasks';
    this.config = config;
    this.client = null;
    this.accessToken = null;
  }

  // Get OAuth authorization URL
  getAuthUrl() {
    const params = new URLSearchParams({
      client_id:     this.config.clientId,
      response_type: 'code',
      redirect_uri:  this.config.redirectUri,
      scope:         'Tasks.ReadWrite offline_access User.Read',
      response_mode: 'query',
      prompt:        'select_account', // always show account picker so the correct account can be chosen
    });
    return `https://login.microsoftonline.com/${this.config.tenantId}/oauth2/v2.0/authorize?${params}`;
  }

  // Exchange authorization code for tokens
  async getTokensFromCode(code) {
    const body = new URLSearchParams({
      client_id:     this.config.clientId,
      client_secret: this.config.clientSecret,
      code,
      redirect_uri:  this.config.redirectUri,
      grant_type:    'authorization_code',
    });
    const response = await fetch(
      `https://login.microsoftonline.com/${this.config.tenantId}/oauth2/v2.0/token`,
      { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body }
    );
    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error_description || 'Token exchange failed');
    }
    return response.json(); // { access_token, refresh_token, expires_in, ... }
  }

  // Initialize Graph client
  async initialize(accessToken, refreshToken, onTokenRefresh) {
    this.refreshToken    = refreshToken    || null;
    this.onTokenRefresh  = onTokenRefresh  || null;

    if (accessToken) {
      this.accessToken = accessToken;
      this._initClient();
    } else if (this.config.clientId && this.config.clientSecret && this.config.tenantId) {
      // Use client credentials flow (for service-to-service)
      const credential = new ClientSecretCredential(
        this.config.tenantId,
        this.config.clientId,
        this.config.clientSecret
      );
      const tokenResponse = await credential.getToken('https://graph.microsoft.com/.default');
      this.accessToken = tokenResponse.token;
      this._initClient();
    } else {
      throw new Error('Microsoft Tasks requires authentication. Please provide access token or credentials.');
    }
  }

  _initClient() {
    const self = this;
    this.client = Client.init({
      authProvider: (done) => done(null, self.accessToken)
    });
  }

  // Exchange a refresh token for a new access token and update stored credentials
  async refreshAccessToken() {
    if (!this.refreshToken) throw new Error('No Microsoft refresh token available');

    const body = new URLSearchParams({
      client_id:     this.config.clientId,
      client_secret: this.config.clientSecret,
      refresh_token: this.refreshToken,
      grant_type:    'refresh_token',
    });

    const response = await fetch(
      `https://login.microsoftonline.com/${this.config.tenantId}/oauth2/v2.0/token`,
      { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body }
    );
    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error_description || 'Microsoft token refresh failed');
    }

    const tokens = await response.json();
    this.accessToken = tokens.access_token;
    if (tokens.refresh_token) this.refreshToken = tokens.refresh_token;
    this._initClient();

    if (this.onTokenRefresh) {
      await this.onTokenRefresh({
        accessToken:  this.accessToken,
        refreshToken: this.refreshToken,
      });
    }

    return { accessToken: this.accessToken, refreshToken: this.refreshToken };
  }

  // Get all task lists
  async getLists() {
    if (!this.client) {
      throw new Error('Client not initialized. Call initialize() first.');
    }

    const response = await this.client
      .api('/me/todo/lists')
      .get();

    return response.value.map(list => ({
      id: list.id,
      name: list.displayName,
      isOwner: list.isOwner,
      isShared: list.isShared
    }));
  }

  // Get tasks from a specific list
  async getTasks(listId) {
    if (!this.client) {
      throw new Error('Client not initialized. Call initialize() first.');
    }

    const response = await this.client
      .api(`/me/todo/lists/${listId}/tasks`)
      .get();

    return response.value.map(task => ({
      id: task.id,
      name: task.title,
      completed: task.status === 'completed',
      importance: task.importance,
      priority: task.importance || 'low',
      dueDate: task.dueDateTime?.dateTime,
      createdDate: task.createdDateTime,
      updated: task.lastModifiedDateTime,
      notes: extractNotes(task.body)
    }));
  }

  // Get task details
  async getTask(listId, taskId) {
    if (!this.client) {
      throw new Error('Client not initialized. Call initialize() first.');
    }

    const task = await this.client
      .api(`/me/todo/lists/${listId}/tasks/${taskId}`)
      .get();

    return {
      id: task.id,
      name: task.title,
      completed: task.status === 'completed',
      importance: task.importance,
      priority: task.importance || 'low',
      dueDate: task.dueDateTime?.dateTime,
      createdDate: task.createdDateTime,
      lastModified: task.lastModifiedDateTime,
      notes: extractNotes(task.body),
      categories: task.categories
    };
  }

  // Mark task as complete
  async completeTask(listId, taskId) {
    if (!this.client) {
      throw new Error('Client not initialized. Call initialize() first.');
    }

    await this.client
      .api(`/me/todo/lists/${listId}/tasks/${taskId}`)
      .patch({
        status: 'completed'
      });

    return { success: true, message: 'Task marked as complete' };
  }

  // Get task counts for all lists in parallel
  async getListCounts(onlyIncomplete = false) {
    const lists = await this.getLists();
    const counts = {};
    await Promise.all(lists.map(async (list) => {
      try {
        const tasks = await this.getTasks(list.id);
        counts[list.id] = onlyIncomplete ? tasks.filter(t => !t.completed).length : tasks.length;
      } catch {
        counts[list.id] = 0;
      }
    }));
    return counts;
  }

  // Update an existing task
  async updateTask(listId, taskId, taskData) {
    if (!this.client) throw new Error('Client not initialized. Call initialize() first.');

    const patch = {};
    if (taskData.name)                patch.title = taskData.name;
    if (taskData.notes !== undefined)  patch.body = { content: taskData.notes || '', contentType: 'text' };
    if (taskData.dueDate)              patch.dueDateTime = { dateTime: `${taskData.dueDate}T00:00:00.000000`, timeZone: 'UTC' };
    else if (taskData.dueDate === null) patch.dueDateTime = null;
    if (taskData.priority !== undefined) patch.importance = taskData.priority === 'none' ? 'low' : taskData.priority;

    await this.client.api(`/me/todo/lists/${listId}/tasks/${taskId}`).patch(patch);
    return { success: true, message: 'Task updated' };
  }

  // Delete a task
  async deleteTask(listId, taskId) {
    if (!this.client) throw new Error('Client not initialized. Call initialize() first.');
    await this.client.api(`/me/todo/lists/${listId}/tasks/${taskId}`).delete();
    return { success: true, message: 'Task deleted' };
  }

  // Create a new task
  async createTask(listId, taskData) {
    if (!this.client) {
      throw new Error('Client not initialized. Call initialize() first.');
    }

    const taskPayload = {
      title: taskData.name || taskData.title || 'Untitled Task'
    };

    if (taskData.notes || taskData.description) {
      taskPayload.body = {
        content: taskData.notes || taskData.description,
        contentType: 'text'
      };
    }

    if (taskData.dueDate) {
      taskPayload.dueDateTime = {
        dateTime: taskData.dueDate,
        timeZone: 'UTC'
      };
    }

    taskPayload.importance = taskData.priority === 'high' ? 'high'
      : taskData.priority === 'normal' ? 'normal'
      : taskData.importance || 'low';

    const task = await this.client
      .api(`/me/todo/lists/${listId}/tasks`)
      .post(taskPayload);

    return {
      id: task.id,
      name: task.title
    };
  }
}

module.exports = MicrosoftTasksProvider;
